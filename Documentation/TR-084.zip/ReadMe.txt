The directory Word2010 contains a version of the XMl->Doc document generator for systems using Microsoft Word 2010.

The directory Word2007 contains a version of the XMl->Doc document generator for systems using Microsoft Word 2007. 
