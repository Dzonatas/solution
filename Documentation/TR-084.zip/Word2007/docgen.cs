// Copyright(c) 2001, 2002 Intel Corporation. All Rights Reserved.
// Created By: J. Marcey
// Edited By: Joel Marcey, Twin Roots, 2010

namespace Intel.DSL.ECMA
{
    using System;
    using System.Runtime.InteropServices;
    using System.Xml;
    using System.Xml.XPath;
    using System.Xml.Xsl;
    using System.Collections;
    using System.IO;
    using System.Collections.Generic;
    using Microsoft.Office.Interop.Word;

    public class DocGen
    {
        private string xmlfile, xslfile, htmFile, svDocPath;
        private ArrayList docNames, namespaces, librariesTransformed;
#if Off2010
        private DocumentClass docAll;
        private ApplicationClass wapp;
#elif Off2007
        private Document docAll;
        private Application wapp;
#endif
        private object opt = Type.Missing;
        private string docExtension = ".doc";
      
        // Use if htm file exists...i.e. if transform has been done
        public DocGen(string xml, string htm, string svDoc) : this(xml, null, htm, svDoc)
        {
        }

        // Use if the transform needs to be done
        public DocGen(string xml, string xsl, string htm, string svDoc)
        {
            this.svDocPath = Path.GetFullPath(svDoc);
            if (!this.svDocPath.EndsWith("\\"))
            {
                this.svDocPath = this.svDocPath + "\\";
            }
            if (!Directory.Exists(this.svDocPath))
            {
                Directory.CreateDirectory(this.svDocPath);
            }
            this.xmlfile = xml;
            this.htmFile = this.svDocPath + htm;
            this.xslfile = xsl;
            librariesTransformed = new ArrayList();
        }

        private void GetDocNames(bool useNamespaceInDocName, bool useNamespaceDirStructure)
        {
            docNames = new ArrayList();
            namespaces = new ArrayList();

            // Don't want to add any names to the docNames/namespaces array lists if the
            // type is excluded from the standard or not part of a library that was
            // transformed.
            ArrayList typeExcluded = new ArrayList();
            ArrayList partOfTransformedLibrary = new ArrayList();

            try
            {
                Console.Write("Getting the document names from the XML....");
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(this.xmlfile);
                XPathNavigator nav = ((IXPathNavigable)xmldoc).CreateNavigator();

                // Get the excluded value of each type
                String expr = "descendant::Type/TypeExcluded/text()";
  
                XPathNodeIterator expIterator = nav.Select(expr);
                while(expIterator.MoveNext())
                {
                    Console.Write(".");
                    typeExcluded.Add(expIterator.Current.Value);
                }


                // Get what library each type is a member of and see if
                // it is in the set of libaries that were actually transformed
                expr = "descendant::Type/MemberOfLibrary/text()";
                expIterator = nav.Select(expr);
                while (expIterator.MoveNext())
                {
                    Console.Write(".");
                    // 0 means the GetLibrariesTransformed method was not called and assume all is valid.
                    if (librariesTransformed.Count == 0 || librariesTransformed.Contains("__ALL__") || librariesTransformed.Contains(expIterator.Current.Value))
                    {
                        partOfTransformedLibrary.Add(true);
                    }
                    else
                    {
                        partOfTransformedLibrary.Add(false);
                    }
                }

                expr = "descendant::Type/@FullName";
                expIterator = nav.Select(expr);
                String fullname;
                String nsName;
                String docName;
                int x;
                int y = 0;
                Dictionary<string, int> multiples = new Dictionary<string, int>();

                // Might be more efficient to have 4 if statements for each possible combination
                // of the bools and the while embedded in there. Also could use 
                // descendant::Type/@Name/text() for the case of 
                // useNamespaceInDocName == false and useNamespaceDirStructure == false
                // instead of doing the substringing. But this method works well.
                while (expIterator.MoveNext())
                {
                    Console.Write(".");
                    // Only if the type is not excluded
                    if (Convert.ToByte(typeExcluded[y].ToString()) == 0 && Convert.ToBoolean(partOfTransformedLibrary[y].ToString()))
                    {
                        if (useNamespaceInDocName && !useNamespaceDirStructure)
                        {
                            Console.WriteLine("Adding: " + expIterator.Current.Value);
                            docNames.Add(expIterator.Current.Value);
                        }
                        else
                        {
                            fullname = expIterator.Current.Value;
                            // If there was a namespace tag, would not really have to do it like this.
                            // But at this point there is no such tag, so I am parsing the fullname
                            // to retrieve the name space, for the directory structure and the actual 
                            // class name, which will be used for the doc name
                            // ***** JM 23 Dec 2004 ******
                            // Adding for nested, generic types (e.g. List<T>.Enumerator)
                            // Want the nsName to be the same as List<T>, for example
                            if (fullname.IndexOf('<') != -1)
                            {
                                string temp = fullname.Substring(0, fullname.IndexOf('<'));
                                x = temp.LastIndexOf(".");
                            }
                            else
                            {
                                x = fullname.LastIndexOf(".");
                            }
                            nsName = fullname.Substring(0,x);
                            // Replace the '.' in the namespace with '\' for directory structure
                            nsName = nsName.Replace('.', '\\');
                            docName = fullname.Substring(x+1);
                            // ***** JM 26 March 2004 ******
                            // Adding this for generics. Windows doesn't like <> in the file name
                            // ***** JM 23 December 2004 ******
                            // Adding check for nested generic types (e.g. List<T>.Enumerator).
                            // If there is a "." after the <T>, for example, want to make sure to include in the docName
                            if (docName.IndexOf('<') != -1 && docName.IndexOf(".") != -1)
                                docName = docName.Substring(0, docName.IndexOf('<')) + "_GENERIC_" + docName.Substring(docName.IndexOf(".")+1);
                            else if (docName.IndexOf('<') != -1)
                                docName = docName.Substring(0, docName.IndexOf('<')) + "_GENERIC";
                            // ****** JM 28 August 2010 ******
                            // Because we can have two type names that look the same given contravariance, etc.
                            if (docNames.Contains(docName))
                            {
                                if (!multiples.ContainsKey(docName))
                                    multiples.Add(docName, 2);
                                docName = docName + "_" + multiples[docName]++.ToString();
                            }
                            if (useNamespaceDirStructure)
                            {
                                Console.WriteLine("Adding Namespace (dir structure): " + nsName);
                                namespaces.Add(nsName);
                                if (!Directory.Exists(this.svDocPath + nsName))
                                {
                                    Directory.CreateDirectory(this.svDocPath + nsName);
                                }
                            }
                            if (useNamespaceInDocName)
                            {
                                Console.WriteLine("Adding Doc Name: " + fullname);
                                docNames.Add(fullname);
                            }
                            else
                            {
                                Console.WriteLine("Adding Doc Name: " + docName);
                                docNames.Add(docName);   
                            }
                        }
                    }
                    y++;
                }
                Console.WriteLine(".DONE....");
            }
            catch (Exception ex)
            {
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
        }

        public void TransformXMLToHtm()
        {
            // Was going to use XslCompiledTransform instead, but it produced a noticeable different behavior around fonts where the element was empty.
            // Specifically in the Ecma case if the XML had a <paramref name =""/>, it would keep the italic font that is given to paramref in the XSL 
            // throughout the rest of the entire class library set. Int16.Parse(string) was where this behavior reared its head.
            try
            {
                Console.Write("Transforming the XML to HTML");
                //XsltSettings settings = new XsltSettings(true, true);
                //Create a new XslCompiledTransform
                XslTransform xslt = new XslTransform();
                //XslCompiledTransform xslt = new XslCompiledTransform();
                //Load an XSL stylesheet
                xslt.Load(this.xslfile);
                //xslt.Load(this.xslfile, settings, new XmlUrlResolver());
                //Create a new XmlDocument to load XML data from a file.
                XmlDocument mydata = new XmlDocument();
                //Load the XML data file
                mydata.Load(this.xmlfile);
                //Create an XmlTextWriter to transform output to the html file.
                //Saves it at the Doc path specified
                XmlTextWriter writer = new XmlTextWriter(this.htmFile, null);
                //Transform the data and output the result.
                xslt.Transform(((IXPathNavigable)mydata).CreateNavigator(),null,writer);
                writer.Close();
                Console.WriteLine(".....DONE....");
            }
            catch (XmlException ex)
            {
                //Console.WriteLine(ex.Message);
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
        }

        public void GetLibrariesTransformed(char escapeChar, char splitChar)
        {
            object mvText = (object) escapeChar.ToString();
            int x = wapp.Selection.MoveUntil(ref mvText, ref opt);
            Range r = wapp.Selection.Range;
            r.Start = 0;
            r.End = x;
            r.Select();
            string temp = string.Empty;
            for (int i = 1; i <= wapp.Selection.Characters.Count; i++)
            {
                temp += wapp.Selection.Characters[i].Text;
            }
            wapp.Selection.Delete(ref opt, ref opt);
            Console.WriteLine(temp);
            char[] ca = {splitChar, escapeChar};
            temp = temp.TrimEnd(ca);
            Console.WriteLine(temp);
            char[] ca2 = {splitChar};
            string[] libs = temp.Split(ca2);
            Console.WriteLine(libs.Length);
            foreach (string s in libs)
            {
                Console.WriteLine(s);
                if (!s.Equals(String.Empty))
                {
                    this.librariesTransformed.Add(s);
                }
            }
            Console.WriteLine(librariesTransformed.Count);
        }

        public void TransformHtmToWord()
        {
            try
            {
                Console.Write("Opening HTM as Word file...");
#if Off2010
                wapp = new ApplicationClass();
#elif Off2007
                wapp = (Application) new Application();
#endif
				
                wapp.WindowState = WdWindowState.wdWindowStateNormal;
                wapp.Width = 100;
                wapp.Height = 20;
                wapp.Visible = true;
                //wapp.Visible = false;
                object oDocVis = (object) true;
                //object oDocVis = (object) false;
                object oDoc = (object) this.htmFile;
                object oFormat = (object) WdOpenFormat.wdOpenFormatWebPages;
                object oRecentFiles = (object) false;
#if Off2010
                docAll = (DocumentClass) wapp.Documents.Open(ref oDoc, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref oFormat, ref opt, ref oDocVis, ref opt, ref opt, ref opt, ref opt);
#elif Off2007
                docAll = wapp.Documents.Open(ref oDoc, ref opt, ref opt, ref oRecentFiles, ref opt, ref opt, ref opt, ref opt, ref opt, ref oFormat, ref opt, ref oDocVis, ref opt, ref opt, ref opt);               
#endif
                object svDocAll = (object) this.svDocPath + "All_Classes.doc";
                object svFormat = (object) WdSaveFormat.wdFormatDocument;
                object svRecentFiles = (object) false;

                docAll.SaveAs(ref svDocAll, ref svFormat, ref opt, ref opt, ref svRecentFiles, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt);            
                docAll.ActiveWindow.Visible = true;
                //docAll.ActiveWindow.Visible = false;
                //docAll.ActiveWindow.View.Type = WdViewType.wdPrintView;
                docAll.ActiveWindow.View.Type = WdViewType.wdNormalView;
                Console.WriteLine("...DONE....");
            }
            catch (COMException ex)
            {
                /*Console.WriteLine("COM Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);*/
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
            catch (Exception ex)
            {
                /*Console.WriteLine("Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);*/
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
        }

        public void Word_CreateIndividualDocuments(char docBreakToken, bool useNamespaceInDocName, bool useNamespaceDirStructure)
        {
            // Create individual documents by using the division symbol as the catalyst
            // to know when to create docs. Is there a better way? I looked for a method
            // that could act like MoveUntil, but looked for an entire string except for
            // a character in a character set....if there was such a method, the division
            // symbol mechanism would not be necessary.
            int x = -1;
            Range r;
#if Off2010
            DocumentClass docClass = null;
#elif Off2007
            Document docClass = null;
#endif
            int filenum = 0;
            object svDocClass = new Object();
            object svFormat = new Object();
#if !ISO
            LineNumbering ln;
#endif
            HeaderFooter footer;
            object oDocVis = (object) true;
            //object oDocVis = (object) false;

            try
            {
                this.GetDocNames(useNamespaceInDocName, useNamespaceDirStructure);
                //JM--09/29/2002
                // No docNames were found. Probably because the XSL specified libraries
                // to transform of which none of the XML were a part of.
                if (docNames.Count == 0)
                {
                    Console.WriteLine("No doc names found/matched. Probably because the XSL specified libraries to transform of which none of the types in the given XML were a part of.");
                    object fls = (object) false;
                    wapp.Quit(ref fls, ref opt, ref opt);
                    wapp = null;
                    return;
                }
                //------
                if (this.docExtension.Equals(".doc"))
                {
                    svFormat = (object) WdSaveFormat.wdFormatDocument;
                }
                else if (this.docExtension.Equals(".txt") || this.docExtension.Equals(".cs"))
                {
                    svFormat = (object) WdSaveFormat.wdFormatUnicodeText;
                }
			    

                // Positions the cursor at the beginning of the document
                object story = WdUnits.wdStory;
                wapp.Selection.StartOf(ref story, ref opt);
			    
                object mvText = (object) docBreakToken.ToString();
                object tab = (object) '\t'.ToString();

                // For every class, create a new document
                while (x!=0)
                {
                    x = wapp.Selection.MoveUntil(ref mvText, ref opt);
                    if (x != 0)
                    {
                        Console.Write("Selecting and cutting from master doc");
                        // Select from beginning of doc to div symbol
                        r = wapp.Selection.Range;
                        r.Start = 0;
                        r.End = x;
                        r.Select();
                        // Cut the selection out of the document
                        wapp.Selection.Cut();
                        // create a new document
#if Off2010
                        docClass = (DocumentClass) wapp.Documents.Add(ref opt, ref opt, ref opt, ref oDocVis);
#elif Off2007
                        docClass = wapp.Documents.Add(ref opt, ref opt, ref opt, ref oDocVis);
#endif
                        // Means we are not using namespaces as directory structure
                        if (namespaces.Count == 0)
                        {
                            svDocClass = (object) (this.svDocPath + docNames[filenum].ToString() + this.docExtension);
                        }
                        else
                        {
                            svDocClass = (object) (this.svDocPath + namespaces[filenum].ToString() + "\\" + docNames[filenum].ToString() + this.docExtension);
                            Console.WriteLine("The path is: " + svDocClass.ToString());
                        }

                        // So we can see the line numbers
                        docClass.ActiveWindow.View.Type = WdViewType.wdPrintView;

                        // Save it
                        docClass.SaveAs(ref svDocClass, ref svFormat, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt);

                        // paste what was cut in the new document
                        wapp.Selection.Paste();

                        // Put each member of the current type on an individual page
                        if (this.docExtension.Equals(".doc"))
                        {
                            this.Word_SearchReplacePageBreak("#Page Break Here#");
                        }

                        // Remove the division symbol from the newly created document
                        this.Word_SearchReplace(mvText.ToString(), String.Empty);

                        // Remove any tabs from source code
                        if (this.docExtension.Equals(".cs"))
                        {
                            this.Word_SearchReplace(tab.ToString(), String.Empty);
                        }
                        // Only want to get line numbers if we are creating documents (i.e. if creating something like
                        // source code, then no)
                        if (this.docExtension.Equals(".doc"))
                        {
#if !ISO
                            // Get the line numbering going
                            ln = docClass.PageSetup.LineNumbering;
                            // What int represents TRUE?? -1!!! Why?? This should really take a bool
                            ln.Active = -1; // -1 is true;                                                                 
                            ln.CountBy = 1;
                            ln.RestartMode = WdNumberingRule.wdRestartPage;
#else
                            // No line numbers for ISO docs
#endif
                            // Turn on/off tracking of changes
                            docClass.TrackRevisions = false; //true;
                            // Turn on page numbers
                            footer = docClass.Sections.First.Footers[WdHeaderFooterIndex.wdHeaderFooterPrimary];
                            footer.PageNumbers.Add(ref opt, ref opt);
                        }
                        // save and close the newly created document
			    		
                        Range rSmaller = wapp.Selection.Range;
                        rSmaller.Start = 0;
                        rSmaller.End = 1;
                        rSmaller.Select();
                        wapp.Selection.Copy();

                        Console.WriteLine("....saving to indivdual docs" + svDocClass);
                        docClass.Save();
                        docClass.Close(ref opt, ref opt, ref opt);
                        filenum++;
                    }
                }
                docAll.Save();
                docAll.Close(ref opt, ref opt, ref opt);
                // How do I clear the clipboard??
                wapp.Quit(ref opt, ref opt, ref opt);
                wapp = null;
            }
            catch (COMException ex)
            {
                /*Console.WriteLine("COM Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);*/
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
            catch (Exception ex)
            {
                /*Console.WriteLine("Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);*/
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
            finally
            {
                if (docClass != null)
                    try
                    {
                    }
                    catch
                    {
                    }
                if (docAll != null)
                    try
                    {
                    }
                    catch
                    {
                    }
            }
        }

        public void Word_CreateIndividualDocuments(char docBreakToken, string docExt, bool useNamespaceInDocName, bool useNamespaceDirStructure)
        {
            this.docExtension = docExt;
            this.Word_CreateIndividualDocuments(docBreakToken, useNamespaceInDocName, useNamespaceDirStructure);
        }

        public void Word_SearchReplace(string findText, string replaceText)
        {
            try
            {
                // Positions the cursor at the beginning of the document
                object story = WdUnits.wdStory;
                wapp.Selection.StartOf(ref story, ref opt);

                Find f = wapp.Selection.Find;
                object fText;
                object rText;
                object forward;
                object cont;
                object rAll;

                fText = (object) findText;
                rText = (object) replaceText;
                f.ClearFormatting();
                forward = (object) true;
                cont = (object) WdFindWrap.wdFindContinue;
                rAll = (object) WdReplace.wdReplaceAll;
                f.Execute(ref fText, ref opt, ref opt, ref opt, ref opt, ref opt, ref forward, ref cont , ref opt, ref rText, ref rAll, ref opt, ref opt, ref opt, ref opt);
            }
            catch (COMException ex)
            {
                /*Console.WriteLine("COM Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);*/
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
            catch (Exception ex)
            {
                /*Console.WriteLine("Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);*/
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
        }

        public void Word_SearchReplacePageBreak(string findText)
        {
            try
            {
                // Positions the cursor at the beginning of the document
                object story = WdUnits.wdStory;
                wapp.Selection.StartOf(ref story, ref opt);

                Find f = wapp.Selection.Find;
                object fText;
                object rText;

                fText = (object) findText;
                rText = (object) String.Empty;
                f.ClearFormatting();
                while (f.Execute(ref fText, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref opt, ref rText, ref opt, ref opt, ref opt, ref opt, ref opt))
                {
                    wapp.Selection.InsertBreak(ref opt);
                }
            }
            catch (COMException ex)
            {
                /*Console.WriteLine("COM Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);*/
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
            catch (Exception ex)
            {
                /*Console.WriteLine("Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);*/
                if (wapp != null)
                    wapp.Quit(ref opt, ref opt, ref opt);
                throw(ex);
            }
        }

        public static int Main(string[] args)
        {
            string ext = null;
            string xmlfile = null;
            string xslfile = null;
            string svPath = null;
            bool nsd = false;
            bool nsn = false;
            string tempHtmFile = "allclasses.htm";

            if (args.Length < 4)
            {
                DocGen.Usage();
                return 1;
            }

            if (!args[0].Equals(".doc") && !args[0].Equals(".cs") && !args[0].Equals(".txt"))
            {
                DocGen.Usage();
                return 1;
            }
            
            if (!File.Exists(args[1]))
            {
                Console.WriteLine("\n   Could not find XML file {0}\n", args[1]);
                return 1;
            }

            if (!File.Exists(args[2]))
            {
                Console.WriteLine("\n   Could not find XSL file {0}\n", args[2]);
                return 1;
            }
            if (args[3].StartsWith("-")) //(!Directory.Exists(args[3]))
            {
                Console.WriteLine("\n   Could not create directory {0}\n", args[3]);
                return 1;
            }
            // Use namespace for directory structure or namespace in doc name structure?
            if (args.Length >= 5)
            {
                if (args[4].ToUpper().Equals("-NSD"))
                {
                    nsd = true;
                }
                else if (args[4].ToUpper().Equals("-NSN"))
		        {
		            nsn = true;
		        }
                else
                {
                    Console.WriteLine("\n   Don't understand option{0}\n", args[4]);
                    return 1;
                }
            }
            if (args.Length == 6)
            {
                if (args[5].ToUpper().Equals("-NSN"))
                {
                    nsn = true;
                }
                else if (args[5].ToUpper().Equals("-NSD"))
                {
                    nsd = true;
                }
                else
                {
                    Console.WriteLine("\n   Don't understand option{0}\n", args[4]);
                    return 1;
                }
            }
            
            Console.WriteLine("Tool has started. The tool has completed when you are able to type at the command prompt again.\nIf something goes wrong, you should see an exception.\nIt is recommended that you leave the machine alone while tool is running.");
            ext = args[0];
            xmlfile = args[1];
            xslfile = args[2];
            svPath = args[3];

            ArrayList replaceFrom = new ArrayList();
            ArrayList replaceTo = new ArrayList();
            // Set some default values
            				
            replaceFrom.Add("#Document Change Here#");
            replaceTo.Add("(word document change)");

            replaceFrom.Add("#Type Break#");
            replaceTo.Add("(word document change)");

            replaceFrom.Add(" ,");
            replaceTo.Add(",");

            replaceFrom.Add(" .");
            replaceTo.Add(".");

            replaceFrom.Add(" ;");
            replaceTo.Add(";");

            replaceFrom.Add(" :");
            replaceTo.Add(":");

            replaceFrom.Add(" ]");
            replaceTo.Add("]");

            //JM 15 Oct 2002
            replaceFrom.Add("void.ctor");
            replaceTo.Add("void .ctor");

            try
            {
                DocGen dgen = null;
                if (args.Length == 7 && args[6].Equals("-H2D"))
                {
                    dgen = new DocGen(xmlfile, tempHtmFile, svPath);
                    dgen.TransformHtmToWord();
                }
                // If ever converting a big Word doc to smaller Word docs
                /*else if (args.Length == 7 && args[6].Equals("-D2D"))
                {
                }*/
                else // Default is XML to Doc Conversion
                {
                    dgen = new DocGen(xmlfile, xslfile, tempHtmFile, svPath);
                    dgen.TransformXMLToHtm();
                    dgen.TransformHtmToWord();
                }
               	
                dgen.GetLibrariesTransformed('#', ',');
                char div = '\u00F7';
                for (int i = 0; i < replaceFrom.Count;i++)
                {
                    if(replaceTo[i].ToString().Equals("(word document change)"))
                    {
                        dgen.Word_SearchReplace(replaceFrom[i].ToString(), div.ToString()); //division symbol 
                    }
                    else if(replaceTo[i].ToString().Equals("(empty string)"))
                    {
                        dgen.Word_SearchReplace(replaceFrom[i].ToString(), String.Empty);
                    }
                    else
                    {
                        dgen.Word_SearchReplace(replaceFrom[i].ToString(), replaceTo[i].ToString());
                    }
                }
                dgen.Word_CreateIndividualDocuments(div, ext, nsn, nsd);
                Console.WriteLine("......DONE.......");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: ");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("StackTrace: " + ex.StackTrace);
                
            }

            return 0;
        }

        public static void Usage()
        {
            Console.WriteLine("\n   DocBuilder.exe <DocType> <XMLDoc> <XSLDoc> <OutputDir> [-NSD(Namespaces for Directory Structure)] [-NSN(Namespace Part of Doc Name)]\n"); // [-X2D | -H2D]\n");
            Console.WriteLine("    Where <DocType> is '.doc', '.cs', '.txt'\n");
            //Console.WriteLine("    and -X2D is raw XML to a document/source file (default), -H2D is HTM file to a document/source file\n");
        }
    }
}